<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * 优惠券使用日志.
 */
class CouponLog extends Model
{
    public const UPDATED_AT = null;
    protected $table = 'coupon_log';
}
