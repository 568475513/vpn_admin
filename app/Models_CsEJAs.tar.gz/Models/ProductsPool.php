<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * 产品名称池.
 */
class ProductsPool extends Model
{
    protected $table = 'products_pool';
    protected $guarded = [];
}
