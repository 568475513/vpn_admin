<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * 伪装域名证书.
 */
class NodeCertificate extends Model
{
    protected $table = 'node_certificate';
    protected $guarded = [];
}
